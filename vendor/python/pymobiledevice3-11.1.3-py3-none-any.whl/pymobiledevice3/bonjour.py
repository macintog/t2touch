# Async, dependency-light mDNS browser returning dataclasses with per-address interface names.
# Works for any DNS-SD type, e.g. "_remoted._tcp.local."
# - Uses ifaddr (optional) to map IPs -> local interfaces; otherwise iface will be None.

import asyncio
import contextlib
import ipaddress
import socket
import struct
import sys
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, field
from types import TracebackType
from typing import Any, Callable, Optional, TypeVar, cast

import ifaddr  # pip install ifaddr
from typing_extensions import dataclass_transform

from pymobiledevice3.osu.os_utils import get_os_utils

REMOTEPAIRING_SERVICE_NAME = "_remotepairing._tcp.local."
REMOTEPAIRING_MANUAL_PAIRING_SERVICE_NAME = "_remotepairing-manual-pairing._tcp.local."
REMOTEPAIRING_PAIRABLE_HOST_SERVICE_NAME = "_remotepairing-pairable-host._tcp.local."
MOBDEV2_SERVICE_NAME = "_apple-mobdev2._tcp.local."
REMOTED_SERVICE_NAME = "_remoted._tcp.local."
OSUTILS = get_os_utils()
DEFAULT_BONJOUR_TIMEOUT = OSUTILS.bonjour_timeout

MDNS_PORT = 5353
MDNS_MCAST_V4 = "224.0.0.251"
MDNS_MCAST_V6 = "ff02::fb"

QTYPE_A = 1
QTYPE_PTR = 12
QTYPE_TXT = 16
QTYPE_AAAA = 28
QTYPE_SRV = 33

CLASS_IN = 0x0001
CLASS_QU = 0x8000  # unicast-response bit (we use multicast queries)


# ---------------- Dataclasses ----------------


_T = TypeVar("_T")


# --- Dataclass decorator shim (adds slots only on 3.10+)
@dataclass_transform(field_specifiers=(field,))
def dataclass_compat(*d_args: Any, **d_kwargs: Any) -> Callable[[type[_T]], type[_T]]:
    if sys.version_info < (3, 10):
        d_kwargs.pop("slots", None)  # ignore on 3.9
    return dataclass(*d_args, **d_kwargs)


@dataclass_compat(slots=True)
class Address:
    ip: str
    iface: str  # local interface name (e.g., "en0"), or None if unknown

    @property
    def full_ip(self) -> str:
        if self.iface and self.ip.lower().startswith("fe80:"):
            return f"{self.ip}%{self.iface}"
        return self.ip


@dataclass_compat(slots=True)
class ServiceInstance:
    instance: str  # "<Instance Name>._type._proto.local."
    host: Optional[str]  # "host.local" (without trailing dot), or None if unresolved
    port: int  # SRV port (always present — browse_service skips port-less SRV entries)
    addresses: list[Address] = field(default_factory=list[Address])  # IPs with interface names
    properties: dict[str, str] = field(default_factory=dict[str, str])  # TXT key/values


# ---------------- DNS helpers ----------------


def encode_name(name: str) -> bytes:
    name = name.rstrip(".")
    out = bytearray()
    for label in name.split(".") if name else []:
        b = label.encode("utf-8")
        if len(b) > 63:
            raise ValueError("label too long")
        out.append(len(b))
        out += b
    out.append(0)
    return bytes(out)


def decode_name(data: bytes, off: int) -> tuple[str, int]:
    labels: list[str] = []
    jumped = False
    orig_end = off
    for _ in range(128):  # loop guard
        if off >= len(data):
            break
        length = data[off]
        if length == 0:
            off += 1
            break
        if (length & 0xC0) == 0xC0:
            if off + 1 >= len(data):
                raise ValueError("truncated name pointer")
            ptr = ((length & 0x3F) << 8) | data[off + 1]
            if ptr >= len(data):
                raise ValueError("bad name pointer")
            if not jumped:
                orig_end = off + 2
            off = ptr
            jumped = True
            continue
        off += 1
        end = off + length
        if end > len(data):
            raise ValueError("truncated label")
        labels.append(data[off:end].decode("utf-8", errors="replace"))
        off = end
    return ".".join(labels) + ".", (orig_end if jumped else off)


def build_query(name: str, qtype: int, unicast: bool = False) -> bytes:
    hdr = struct.pack("!HHHHHH", 0, 0, 1, 0, 0, 0)  # TXID=0, flags=0, 1 question
    qclass = CLASS_IN | (CLASS_QU if unicast else 0)
    return hdr + encode_name(name) + struct.pack("!HH", qtype, qclass)


def parse_rr(data: bytes, off: int) -> tuple[dict[str, Any], int]:
    name, off = decode_name(data, off)
    if off + 10 > len(data):
        raise ValueError("truncated RR header")
    rtype, rclass, ttl, rdlen = struct.unpack("!HHIH", data[off : off + 10])
    off += 10
    rdata = data[off : off + rdlen]
    off += rdlen

    rr: dict[str, Any] = {"name": name, "type": rtype, "class": rclass & 0x7FFF, "ttl": ttl}
    if rtype == QTYPE_PTR:
        target, _ = decode_name(data, off - rdlen)
        rr["ptrdname"] = target
    elif rtype == QTYPE_SRV and rdlen >= 6:
        priority, weight, port = struct.unpack("!HHH", rdata[:6])
        target, _ = decode_name(data, off - rdlen + 6)
        rr.update({"priority": priority, "weight": weight, "port": port, "target": target})
    elif rtype == QTYPE_TXT:
        kv: dict[str, str] = {}
        i = 0
        while i < rdlen:
            b = rdata[i]
            i += 1
            seg = rdata[i : i + b]
            i += b
            if not seg:
                continue
            if b"=" in seg:
                k, v = seg.split(b"=", 1)
                kv[k.decode()] = v.decode(errors="replace")
            else:
                kv[seg.decode()] = ""
        rr["txt"] = kv
    elif rtype == QTYPE_A and rdlen == 4:
        rr["address"] = socket.inet_ntop(socket.AF_INET, rdata)
    elif rtype == QTYPE_AAAA and rdlen == 16:
        rr["address"] = socket.inet_ntop(socket.AF_INET6, rdata)
    else:
        rr["raw"] = rdata
    return rr, off


def parse_mdns_message(data: bytes) -> list[dict[str, Any]]:
    if len(data) < 12:
        return []
    _, _, qd, an, ns, ar = struct.unpack("!HHHHHH", data[:12])
    off = 12
    for _ in range(qd):
        _, off = decode_name(data, off)
        off += 4
    rrs: list[dict[str, Any]] = []
    for _ in range(an + ns + ar):
        rr, off = parse_rr(data, off)
        rrs.append(rr)
    return rrs


# ---------------- Interface mapping helpers ----------------


class _Adapters:
    def __init__(self):
        self.adapters: Iterable[ifaddr.Adapter] = ifaddr.get_adapters() if ifaddr is not None else []

    def pick_iface_for_ip(self, ip_str: str, family: int, v6_scopeid: Optional[int]) -> Optional[str]:
        # Prefer scope id for IPv6 link-local
        if family == socket.AF_INET6 and ip_str.lower().startswith("fe80:") and v6_scopeid:
            try:
                return socket.if_indextoname(v6_scopeid)
            except OSError:
                pass

        # Otherwise, try to match destination ip to local subnet via ifaddr
        if not self.adapters:
            return None
        ip = ipaddress.ip_address(ip_str)
        best: tuple[Optional[str], int] = (None, -1)  # (name, prefix_len)
        for ad in self.adapters:
            for ipn in ad.ips:
                if isinstance(ipn.ip, str):
                    # IPv4
                    fam = socket.AF_INET
                    ipn_ip = ipn.ip
                else:
                    # IPv6
                    fam = socket.AF_INET6
                    ipn_ip = ipn.ip[0]
                if fam != family:
                    continue
                net = ipaddress.ip_network(f"{ipn_ip}/{ipn.network_prefix}", strict=False)
                if ip in net and ipn.network_prefix > best[1]:
                    best = (ad.nice_name or ad.name, ipn.network_prefix)
        return best[0]


# ---------------- async sockets ----------------


class _DatagramProtocol(asyncio.DatagramProtocol):
    def __init__(self, queue: asyncio.Queue[tuple[bytes, Any]]):
        self.queue = queue

    def datagram_received(self, data: bytes, addr: Any) -> None:
        # addr: IPv4 -> (host, port); IPv6 -> (host, port, flowinfo, scopeid)
        self.queue.put_nowait((data, addr))


async def _bind_ipv4(queue: asyncio.Queue[tuple[bytes, Any]]):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if hasattr(socket, "SO_REUSEPORT"):
        with contextlib.suppress(OSError):
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    s.bind(("0.0.0.0", MDNS_PORT))
    try:
        mreq = struct.pack("=4s4s", socket.inet_aton(MDNS_MCAST_V4), socket.inet_aton("0.0.0.0"))
        s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    except OSError:
        pass
    transport, _ = await asyncio.get_running_loop().create_datagram_endpoint(lambda: _DatagramProtocol(queue), sock=s)
    return transport, s


async def _bind_ipv6_all_ifaces(queue: asyncio.Queue[tuple[bytes, Any]]):
    s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if hasattr(socket, "SO_REUSEPORT"):
        with contextlib.suppress(OSError):
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    s.bind(("::", MDNS_PORT))
    grp = socket.inet_pton(socket.AF_INET6, MDNS_MCAST_V6)
    for ifindex, _ in socket.if_nameindex():
        mreq6 = grp + struct.pack("@I", ifindex)
        try:
            s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_JOIN_GROUP, mreq6)
        except OSError:
            continue
    transport, _ = await asyncio.get_running_loop().create_datagram_endpoint(lambda: _DatagramProtocol(queue), sock=s)
    return transport, s


async def _open_mdns_sockets() -> tuple[
    list[tuple[asyncio.DatagramTransport, socket.socket]], asyncio.Queue[tuple[bytes, Any]]
]:
    queue: asyncio.Queue[tuple[bytes, Any]] = asyncio.Queue()
    transports: list[tuple[asyncio.DatagramTransport, socket.socket]] = []
    t4, s4 = await _bind_ipv4(queue)
    transports.append((t4, s4))
    t6, s6 = await _bind_ipv6_all_ifaces(queue)
    transports.append((t6, s6))
    if not transports:
        raise RuntimeError("Failed to open mDNS sockets (UDP/5353)")
    return transports, queue


async def _send_query_all(transports: list[tuple[asyncio.DatagramTransport, socket.socket]], pkt: bytes):
    for transport, sock in transports:
        if sock.family == socket.AF_INET:
            transport.sendto(pkt, (MDNS_MCAST_V4, MDNS_PORT))
        else:
            # Send once per iface index for better reachability
            for ifindex, _ in socket.if_nameindex():
                transport.sendto(pkt, (MDNS_MCAST_V6, MDNS_PORT, 0, ifindex))


# ---------------- Public API ----------------


async def browse_service(service_type: str, timeout: float = 4.0) -> list[ServiceInstance]:
    """
    Discover a DNS-SD/mDNS service type (e.g. "_remoted._tcp.local.") on the local network.

    Returns: List[ServiceInstance] with Address(ip, iface) entries.
    """
    if not service_type.endswith("."):
        service_type += "."

    transports, queue = await _open_mdns_sockets()
    adapters = _Adapters()

    ptr_targets: set[str] = set()
    srv_map: dict[str, list[dict[str, Any]]] = defaultdict(list)  # instance_name -> list of {"target", "port"}
    txt_map: dict[str, dict[str, Any]] = {}
    host_addrs: dict[str, list[Address]] = defaultdict(list)  # host -> list[(ip, iface)]

    def _record_addr(rr_name: str, ip_str: str, pkt_addr: Any) -> None:
        # Determine family and possible scopeid from the packet that delivered this RR
        family = socket.AF_INET6 if ":" in ip_str else socket.AF_INET
        scopeid: Optional[int] = None
        if isinstance(pkt_addr, tuple) and len(cast(tuple[Any, ...], pkt_addr)) == 4:  # IPv6 remote tuple
            scopeid = cast(Optional[int], pkt_addr[3])
        iface = adapters.pick_iface_for_ip(ip_str, family, scopeid)
        if iface is None:
            return
        # Avoid duplicates for the same host/ip
        existing = host_addrs[rr_name]
        if not any(a.ip == ip_str for a in existing):
            existing.append(Address(ip=ip_str, iface=iface))

    try:
        await _send_query_all(transports, build_query(service_type, QTYPE_PTR, unicast=False))
        loop = asyncio.get_running_loop()
        end = loop.time() + timeout
        while loop.time() < end:
            try:
                data, pkt_addr = await asyncio.wait_for(queue.get(), timeout=end - loop.time())
            except asyncio.TimeoutError:
                break
            for rr in parse_mdns_message(data):
                t = rr.get("type")
                if t == QTYPE_PTR and rr.get("name") == service_type:
                    ptr_targets.add(cast(str, rr.get("ptrdname")))
                elif t == QTYPE_SRV:
                    srv_map[rr["name"]].append({"target": rr.get("target"), "port": rr.get("port")})
                elif t == QTYPE_TXT:
                    # TODO: This could possibly mix the properties of multiple TXT records for the same instance.
                    #       However, it's currently unused.
                    txt_map[rr["name"]] = rr.get("txt", {})
                elif (t == QTYPE_A and rr.get("address")) or (t == QTYPE_AAAA and rr.get("address")):
                    _record_addr(rr["name"], rr["address"], pkt_addr)
    finally:
        for transport, _ in transports:
            transport.close()

    # Assemble dataclasses
    results: list[ServiceInstance] = []
    for inst in sorted(ptr_targets):
        srv_entries = srv_map.get(inst, [])
        props = txt_map.get(inst, {})
        for srv in srv_entries:
            port = srv.get("port")
            if port is None:
                # SRV records always carry a port; skip malformed/unresolved entries.
                continue
            target = srv.get("target")
            host = (target[:-1] if target and target.endswith(".") else target) or None
            addrs = host_addrs.get(target, []) if target else []
            results.append(
                ServiceInstance(
                    instance=inst,
                    host=host,
                    port=port,
                    addresses=addrs,
                    properties=props,
                )
            )
    return results


async def browse_remoted(timeout: float = DEFAULT_BONJOUR_TIMEOUT) -> list[ServiceInstance]:
    return await browse_service(REMOTED_SERVICE_NAME, timeout=timeout)


async def browse_mobdev2(timeout: float = DEFAULT_BONJOUR_TIMEOUT) -> list[ServiceInstance]:
    return await browse_service(MOBDEV2_SERVICE_NAME, timeout=timeout)


async def browse_remotepairing(timeout: float = DEFAULT_BONJOUR_TIMEOUT) -> list[ServiceInstance]:
    return await browse_service(REMOTEPAIRING_SERVICE_NAME, timeout=timeout)


async def browse_remotepairing_manual_pairing(timeout: float = DEFAULT_BONJOUR_TIMEOUT) -> list[ServiceInstance]:
    return await browse_service(REMOTEPAIRING_MANUAL_PAIRING_SERVICE_NAME, timeout=timeout)


# ---------------- mDNS advertising (responder) ----------------


def _parse_questions(data: bytes) -> list[tuple[str, int]]:
    """Parse the question section of an mDNS query into (name, qtype) pairs."""
    if len(data) < 12:
        return []
    _, _, qd, _, _, _ = struct.unpack("!HHHHHH", data[:12])
    off = 12
    questions: list[tuple[str, int]] = []
    for _ in range(qd):
        try:
            name, off = decode_name(data, off)
        except ValueError:
            break
        if off + 4 > len(data):
            break
        qtype, _qclass = struct.unpack("!HH", data[off : off + 4])
        off += 4
        questions.append((name, qtype))
    return questions


def _build_rr(name: str, rtype: int, rdata: bytes, ttl: int, cache_flush: bool) -> bytes:
    rclass = CLASS_IN | (0x8000 if cache_flush else 0)
    return encode_name(name) + struct.pack("!HHIH", rtype, rclass, ttl, len(rdata)) + rdata


def _encode_txt(properties: dict[str, str]) -> bytes:
    if not properties:
        return b"\x00"
    out = bytearray()
    for key, value in properties.items():
        seg = f"{key}={value}".encode()
        if len(seg) > 255:
            raise ValueError(f"TXT record entry too long: {key}")
        out.append(len(seg))
        out += seg
    return bytes(out)


def _encode_srv(priority: int, weight: int, port: int, target: str) -> bytes:
    return struct.pack("!HHH", priority, weight, port) + encode_name(target)


def _local_addresses() -> list[tuple[int, str]]:
    """Return (family, ip) tuples for usable, non-loopback local addresses."""
    result: list[tuple[int, str]] = []
    if ifaddr is None:
        return result
    for adapter in ifaddr.get_adapters():
        for ip in adapter.ips:
            if isinstance(ip.ip, str):
                addr = ip.ip
                if addr.startswith("127.") or addr == "0.0.0.0":
                    continue
                result.append((socket.AF_INET, addr))
            else:
                addr = ip.ip[0]
                lowered = addr.lower()
                if lowered in ("::1", "::") or lowered.startswith("fe80:"):
                    # Skip loopback and link-local (the latter needs a scope id to be useful)
                    continue
                result.append((socket.AF_INET6, addr))
    return result


class MDNSResponder:
    """
    Minimal mDNS service advertiser.

    Answers PTR/SRV/TXT/A/AAAA queries for a single advertised DNS-SD service and
    sends unsolicited announcements on start and goodbye packets on stop. It is
    deliberately dependency-light (same philosophy as :func:`browse_service`) and
    only implements what an iOS device needs to discover and connect to a
    ``_remotepairing-pairable-host._tcp`` host.
    """

    TTL = 120
    HOST_TTL = 120

    def __init__(
        self,
        service_type: str,
        instance_name: str,
        port: int,
        properties: dict[str, str],
        hostname: Optional[str] = None,
        addresses: Optional[list[tuple[int, str]]] = None,
    ) -> None:
        if not service_type.endswith("."):
            service_type += "."
        self.service_type = service_type
        self.instance_name = instance_name
        self.instance_fqdn = f"{instance_name}.{service_type}"
        self.port = port
        self.properties = properties
        self.hostname = hostname or f"{instance_name.split('.')[0]}.local."
        if not self.hostname.endswith("."):
            self.hostname += "."
        self.addresses = addresses if addresses is not None else _local_addresses()
        # Every local IPv4 interface to steer multicast egress through (see _send_to_all)
        self._ipv4_send_addresses = [ip for family, ip in self.addresses if family == socket.AF_INET]
        self._transports: list[tuple[asyncio.DatagramTransport, socket.socket]] = []
        self._queue: Optional[asyncio.Queue[tuple[bytes, Any]]] = None
        self._serve_task: Optional[asyncio.Task[None]] = None

    def _address_records(self) -> list[bytes]:
        records: list[bytes] = []
        for family, ip in self.addresses:
            if family == socket.AF_INET:
                records.append(
                    _build_rr(self.hostname, QTYPE_A, socket.inet_pton(family, ip), self.HOST_TTL, cache_flush=True)
                )
            else:
                records.append(
                    _build_rr(self.hostname, QTYPE_AAAA, socket.inet_pton(family, ip), self.HOST_TTL, cache_flush=True)
                )
        return records

    def _all_records(self, ttl: Optional[int] = None) -> tuple[list[bytes], list[bytes]]:
        ttl = self.TTL if ttl is None else ttl
        ptr = _build_rr(self.service_type, QTYPE_PTR, encode_name(self.instance_fqdn), ttl, cache_flush=False)
        srv = _build_rr(
            self.instance_fqdn,
            QTYPE_SRV,
            _encode_srv(0, 0, self.port, self.hostname),
            ttl,
            cache_flush=True,
        )
        txt = _build_rr(self.instance_fqdn, QTYPE_TXT, _encode_txt(self.properties), ttl, cache_flush=True)
        answers = [ptr, srv, txt]
        additionals = self._address_records() if ttl else []
        return answers, additionals

    @staticmethod
    def _build_message(answers: list[bytes], additionals: list[bytes]) -> bytes:
        # flags=0x8400 -> response + authoritative answer
        header = struct.pack("!HHHHHH", 0, 0x8400, 0, len(answers), 0, len(additionals))
        return header + b"".join(answers) + b"".join(additionals)

    def _send_to_all(self, packet: bytes) -> None:
        # Send the response/announcement out every interface. For IPv6 we vary the
        # destination scope id; for IPv4 we steer egress per interface via
        # IP_MULTICAST_IF (the local interface address). Without this, the kernel
        # only multicasts out the default interface, so a device on a different
        # interface (e.g. Wi-Fi while the default is a VPN/utun) never sees us.
        for transport, sock in self._transports:
            try:
                if sock.family == socket.AF_INET:
                    sent = False
                    for ipv4 in self._ipv4_send_addresses:
                        try:
                            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ipv4))
                            transport.sendto(packet, (MDNS_MCAST_V4, MDNS_PORT))
                            sent = True
                        except OSError:
                            continue
                    if not sent:
                        transport.sendto(packet, (MDNS_MCAST_V4, MDNS_PORT))
                else:
                    for ifindex, _ in socket.if_nameindex():
                        with contextlib.suppress(OSError):
                            transport.sendto(packet, (MDNS_MCAST_V6, MDNS_PORT, 0, ifindex))
            except OSError:
                continue

    def _announce(self, ttl: Optional[int] = None) -> None:
        answers, additionals = self._all_records(ttl=ttl)
        self._send_to_all(self._build_message(answers, additionals))

    def _matches(self, name: str, qtype: int) -> bool:
        name = name if name.endswith(".") else name + "."
        if name == self.service_type and qtype in (QTYPE_PTR, 255):
            return True
        if name == self.instance_fqdn and qtype in (QTYPE_SRV, QTYPE_TXT, 255):
            return True
        return name == self.hostname and qtype in (QTYPE_A, QTYPE_AAAA, 255)

    async def _serve(self) -> None:
        assert self._queue is not None
        while True:
            data, _pkt_addr = await self._queue.get()
            # Ignore responses; only react to queries (QR bit clear)
            if len(data) < 12:
                continue
            flags = struct.unpack("!H", data[2:4])[0]
            if flags & 0x8000:
                continue
            try:
                questions = _parse_questions(data)
            except Exception:
                continue
            if any(self._matches(name, qtype) for name, qtype in questions):
                answers, additionals = self._all_records()
                self._send_to_all(self._build_message(answers, additionals))

    async def __aenter__(self) -> "MDNSResponder":
        self._transports, self._queue = await _open_mdns_sockets()
        self._serve_task = asyncio.create_task(self._serve())
        # Send a couple of unsolicited announcements so browsing devices notice us quickly
        for _ in range(2):
            self._announce()
            await asyncio.sleep(0.25)
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        if self._serve_task is not None:
            self._serve_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._serve_task
            self._serve_task = None
        # Goodbye: announce the records with TTL 0
        with contextlib.suppress(Exception):
            self._announce(ttl=0)
        for transport, _ in self._transports:
            transport.close()
        self._transports = []
        self._queue = None
